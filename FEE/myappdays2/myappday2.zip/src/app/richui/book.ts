export class Book {
    isbn: string;
    title: string;
    author: string;
}

export const BOOKS = [
    {isbn: "isbn1234567890",title :"1Book on Angular",author : "Susi"},
    {isbn: "isbn1234567888",title :"2Book on Nodejsr",author : "Harsha"},
    {isbn: "isbn1234567899",title :"3Book on JakartaEE",author : "Abirami"},
    {isbn: "isbn1234567897",title :"4Chariots of the God",author : "AncientAliens"}
  ];
