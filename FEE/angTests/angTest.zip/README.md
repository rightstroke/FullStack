ng test --reporters html

ng test --codeCoverage=true