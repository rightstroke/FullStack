package com.rsc.dlvery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DlveryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
