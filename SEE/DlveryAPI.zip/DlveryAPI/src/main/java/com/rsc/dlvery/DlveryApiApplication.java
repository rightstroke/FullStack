package com.rsc.dlvery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DlveryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DlveryApiApplication.class, args);
	}

}
